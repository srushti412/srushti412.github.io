package com.patient.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import com.patient.pojos.Users;
import com.patient.utility.DBConnection;
import com.patient.utility.DateUtil;



public class UsersDAOImpl implements UsersDAO {

	@Override
	public boolean addUser(Users user) {
		try{
		Connection con=DBConnection.getConnection();
		 PreparedStatement prSt = null;
		String query = "insert into users (first_name,last_name,age,gender,contact_number,email,city,state,userid,password,type) values(?,?,?,?,?,?,?,?,?,?,?)";
        prSt =con.prepareStatement(query);
       
        prSt.setString(1,user.getFirst_name());
        prSt.setString(2,user.getLast_name());
        prSt.setInt(3,user.getAge());
        prSt.setString(4,user.getGender());
        prSt.setString(5,user.getContact_number());
        prSt.setString(6,user.getEmail());
        prSt.setString(7,user.getCity());
        prSt.setString(8,user.getState());
        prSt.setString(9,user.getUserid());
        prSt.setString(10,user.getPassword());
        prSt.setString(11,user.getType());
        int count = prSt.executeUpdate();
        if(count>0)
        	return true;
       
		}
		catch(Exception e){
			e.printStackTrace();
		}
        
        
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateUser(Users user) {
		try{
		// TODO Auto-generated method stub
		Connection con=DBConnection.getConnection();
		 PreparedStatement prSt = null;
		String query = "update users set first_name=?,last_name=?,age=?,gender=?,contact_number=?,email=?,city=?,state=?,password=?,type=? where userid=?";
       prSt =con.prepareStatement(query);
      
       prSt.setString(1,user.getFirst_name());
       prSt.setString(2,user.getLast_name());
       prSt.setInt(3,user.getAge());
       prSt.setString(4,user.getGender());
       prSt.setString(5,user.getContact_number());
       prSt.setString(6,user.getEmail());
       prSt.setString(7,user.getCity());
       prSt.setString(8,user.getState());
       prSt.setString(11,user.getUserid());
       prSt.setString(9,user.getPassword());
       prSt.setString(10,user.getType());
       int count = prSt.executeUpdate();
       if(count>0)
    	   return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		
       
		return false;
	}

	@Override
	public boolean deleteUser(String userid) {
		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			 String query = "delete from users where userid=?";
	            prSt = con.prepareStatement(query);
	            prSt.setString(1,userid);
	            int count = prSt.executeUpdate();
	            if(count>0)
	         	   return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Users> getAllUsers() {
		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			String query="select*from users";
            prSt = con.prepareStatement(query);
            ResultSet rs=prSt.executeQuery();
            List<Users>userList=new ArrayList<Users>();
            while(rs.next())
            {
            	Users user=new Users();
            	user.setFirst_name(rs.getString("first_name"));
            	user.setLast_name(rs.getString("last_name"));
            	user.setAge(rs.getInt("age"));
            	user.setGender(rs.getString("gender"));
            	user.setContact_number(rs.getString("contact_number"));
            	user.setEmail(rs.getString("email"));
            	user.setCity(rs.getString("city"));
            	user.setState(rs.getString("state"));
            	user.setUserid(rs.getString("userid"));
            	user.setPassword(rs.getString("password"));
            	user.setType(rs.getString("type"));
            	userList.add(user);
            }
            return userList;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Users getUserById(String userid) {
		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			String query="select* from users where userid=?";
	        prSt = con.prepareStatement(query);
	        prSt.setString(1,userid);
	        ResultSet rs=prSt.executeQuery();
	       
	        if(rs.next())
	        {
	        	Users user=new Users();
	        	user.setFirst_name(rs.getString("first_name"));
            	user.setLast_name(rs.getString("last_name"));
            	user.setAge(rs.getInt("age"));
            	user.setGender(rs.getString("gender"));
            	user.setContact_number(rs.getString("contact_number"));
            	user.setEmail(rs.getString("email"));
            	user.setCity(rs.getString("city"));
            	user.setState(rs.getString("state"));
            	user.setUserid(rs.getString("userid"));
            	user.setPassword(rs.getString("password"));
            	user.setType(rs.getString("type"));
	        	return user;
	        }
		}
		catch(Exception e){
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Users login(String userid, String password) {
		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			 String query="select* from users where userid=? and password=?";
	            prSt = con.prepareStatement(query);
	            prSt.setString(1,userid);
	            prSt.setString(2,password);
	            ResultSet rs=prSt.executeQuery();
	           
	            if(rs.next())
	            {
	            	Users user=new Users();
	            	user.setFirst_name(rs.getString("first_name"));
	            	user.setLast_name(rs.getString("last_name"));
	            	user.setAge(rs.getInt("age"));
	            	user.setGender(rs.getString("gender"));
	            	user.setContact_number(rs.getString("contact_number"));
	            	user.setEmail(rs.getString("email"));
	            	user.setCity(rs.getString("city"));
	            	user.setState(rs.getString("state"));
	            	user.setUserid(rs.getString("userid"));
	            	user.setPassword(rs.getString("password"));
	            	user.setType(rs.getString("type"));
	            	return user;
	            }
	            
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		return null;
	}

	
}
	
	
