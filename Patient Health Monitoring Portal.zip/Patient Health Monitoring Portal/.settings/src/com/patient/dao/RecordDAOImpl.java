package com.patient.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.patient.pojos.Bmi;
import com.patient.pojos.Record;
import com.patient.utility.DBConnection;

public class RecordDAOImpl implements RecordDAO {

	@Override
	public boolean addRecord(Record record) {
		try{
		Connection con=DBConnection.getConnection();
		 PreparedStatement prSt = null;
		String query = "insert into record (userid,tod,rbc,wbc,platelet) values(?,?,?,?,?)";
        prSt =con.prepareStatement(query);
       
        prSt.setString(1,record.getUserid());
        prSt.setString(2,record.getTod());
        prSt.setString(3,record.getRbc());
        prSt.setString(4,record.getWbc());
        prSt.setString(5,record.getPlatelet());
        
       
        int count = prSt.executeUpdate();
        if(count>0)
        	return true;
       
		}
		catch(Exception e){
			e.printStackTrace();
		}
        
        
		// TODO Auto-generated method stub
		return false;
	
		
	}

	@Override
	public boolean updateRecord(Record record) {


		try{
		// TODO Auto-generated method stub
		Connection con=DBConnection.getConnection();
		 PreparedStatement prSt = null;
		String query = "update record set tod=?, rbc=?, wbc=?, platelet=? where userid=?";
       prSt =con.prepareStatement(query);
      
       prSt.setString(1,record.getTod());
       prSt.setString(2,record.getRbc());
       prSt.setString(3,record.getWbc());
       prSt.setString(4,record.getPlatelet());
       prSt.setString(5,record.getUserid());
       
       int count = prSt.executeUpdate();
       if(count>0)
    	   return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		
       
		return false;
	
	
		
	}

	@Override
	public boolean deleteRecord(String userid) {


		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			 String query = "delete from record where userid=?";
	            prSt = con.prepareStatement(query);
	            prSt.setString(1,userid);
	            int count = prSt.executeUpdate();
	            if(count>0)
	         	   return true;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		return false;
	
	
	}

	@Override
	public List<Record> getAllRecord() {


		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			String query="select*from record";
            prSt = con.prepareStatement(query);
            ResultSet rs=prSt.executeQuery();
            List<Record>recordList=new ArrayList<Record>();
            while(rs.next())
            {
            	Record record= new Record();
            	record.setTod(rs.getString("tod"));
            	record.setRbc(rs.getString("rbc"));
            	record.setWbc(rs.getString("wbc"));
            	record.setPlatelet(rs.getString("platelet"));
            	record.setUserid(rs.getString("userid"));
            	
            	recordList.add(record);
            }
            return recordList;
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
		// TODO Auto-generated method stub
		return null;
	
	
	}

	@Override
	public Record getRecordByUserid(String userid) {


		try{
			Connection con=DBConnection.getConnection();
			 PreparedStatement prSt = null;
			String query="select* from record where userid=?";
	        prSt = con.prepareStatement(query);
	        prSt.setString(1,userid);
	        ResultSet rs=prSt.executeQuery();
	       
	        if(rs.next())
	        {
	        	Record record = new Record();
	        	record.setTod(rs.getString("tod"));
	        	record.setRbc(rs.getString("rbc"));
	        	record.setWbc(rs.getString("wbc"));
	        	record.setPlatelet(rs.getString("platelet"));
            	record.setUserid(rs.getString("userid"));
            	
	        	return record;
	        }
		}
		catch(Exception e){
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		return null;
	
	
	}

}
