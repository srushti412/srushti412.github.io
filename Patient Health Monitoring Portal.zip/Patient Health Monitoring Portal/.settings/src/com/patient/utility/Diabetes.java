package com.patient.utility;

public class Diabetes {
	public static boolean risk(String time,int bloodglucose){
		
		 if(time.equals("Morning")&&(bloodglucose>100||bloodglucose<70))
		{
			return true;
		}
		else if(time.equals("Afternoon")&&(bloodglucose>149||bloodglucose<70))
		{
			return true;
		}
		else
			return false;
		
	}

}
