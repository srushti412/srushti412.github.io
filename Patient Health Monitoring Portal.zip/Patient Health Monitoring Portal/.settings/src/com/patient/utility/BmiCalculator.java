package com.patient.utility;

public class BmiCalculator {
	public static float calculateBmi(int height,int weight){
		float bmi=(weight*10000)/(height*height);
		return bmi;
	}
public static void main(String args[])
{
	System.out.println(calculateBmi(30,5));
}
}
