package com.patient.test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.patient.dao.UsersDAO;
import com.patient.dao.UsersDAOImpl;
import com.patient.pojos.Users;

public class Test {

	public static void main(String[] args) {
		Users user=new Users();
		UsersDAO dao=new UsersDAOImpl();
		user.setFirst_name("abc");
    	user.setLast_name("def");
    	user.setAge(20);
    	user.setGender("male");
    	user.setContact_number("123456789");
    	user.setEmail("abc@gmail.com");
    	user.setCity("Pune");
    	user.setState("Maharashtra");
    	user.setUserid("abc1");
    	user.setPassword("abc@08");
    	if((dao.getUserById("abc1")==null))
    	{
    		dao.addUser(user);
        	System.out.println("added");
    	}
    	else
    		System.out.println("Record already exists");
   
    	/*user.setUserid("abc2");
    	user.setContact_number("987654321");
    	if(dao.getUserById("abc2")!=null)
    	{
    		dao.updateUser(user);
        	System.out.println("updated");
    	}
    	else
    		System.out.println("Record does not exist");
    	user.setUserid("abc1");
    	/*if(dao.getUserById("abc1")!=null)
    	{
    		dao.deleteUser("abc1");
        	System.out.println("deleted");
    	}
    	else
    		System.out.println("Record does not exist");*/	
    	List<Users> userList=dao.getAllUsers();
    	
    	for( Users users:userList)
    	{
    		System.out.println(users);
    	}
    	
    	
    	
		// TODO Auto-generated method stub

	}

}
