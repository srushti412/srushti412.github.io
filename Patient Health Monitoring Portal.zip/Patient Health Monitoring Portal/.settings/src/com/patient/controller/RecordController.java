package com.patient.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.patient.dao.BmiDAO;
import com.patient.dao.BmiDAOImpl;
import com.patient.dao.RecordDAO;
import com.patient.dao.RecordDAOImpl;
import com.patient.pojos.Bmi;
import com.patient.pojos.Record;
import com.patient.pojos.Users;

/**
 * Servlet implementation class RecordController
 */
@WebServlet("/RecordController")
public class RecordController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RecordController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RecordDAO record=new RecordDAOImpl();
		HttpSession session=request.getSession();
		List<Record> recordlist=record.getAllRecord();
		session.setAttribute("recordlist",recordlist);
		response.sendRedirect("RecordList.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		Users user=(Users)session.getAttribute("users");
		String tod=request.getParameter("tod");
		String rbc=request.getParameter("rbc");
		String wbc=request.getParameter("wbc");
		String platelet=request.getParameter("platelet");
	   
		System.out.println(tod);
		
		Record record=new Record();
		record.setTod(tod);
		record.setRbc(rbc);
		record.setWbc(wbc);
		record.setPlatelet(platelet);
		
		record.setUserid(user.getUserid());
		RecordDAO dao=new RecordDAOImpl();
		dao.deleteRecord(user.getUserid());
		boolean flag=dao.addRecord(record);
		
		if(flag==true)
		{
			
			session.setAttribute("message","Successsfully recorded");
			
			response.sendRedirect("Record.jsp");
		}
			
		else
		{
			session.setAttribute("message","Failed to record");
		
			response.sendRedirect("Record.jsp");
		}
	
	}

}
