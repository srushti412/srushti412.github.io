package com.patient.pojos;

public class BloodGlucose {
	private String userid;
	private String time;
	private int bloodglucose;
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public int getBloodglucose() {
		return bloodglucose;
	}
	public void setBloodglucose(int bloodglucose) {
		this.bloodglucose = bloodglucose;
	}
	@Override
	public String toString() {
		return "BloodGlucose [userid=" + userid + ", time=" + time + ", bloodglucose=" + bloodglucose + "]";
	}
}

