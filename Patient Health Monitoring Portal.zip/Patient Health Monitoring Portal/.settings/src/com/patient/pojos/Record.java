package com.patient.pojos;

import java.util.Date;

public class Record {
	String userid;
	 String tod;
	 String rbc;
	 String wbc;
	 String platelet;
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getTod() {
		return tod;
	}
	public void setTod(String tod) {
		this.tod = tod;
	}
	public String getRbc() {
		return rbc;
	}
	public void setRbc(String rbc) {
		this.rbc = rbc;
	}
	public String getWbc() {
		return wbc;
	}
	public void setWbc(String wbc) {
		this.wbc = wbc;
	}
	public String getPlatelet() {
		return platelet;
	}
	public void setPlatelet(String platelet) {
		this.platelet = platelet;
	}
	@Override
	public String toString() {
		return "Record [userid=" + userid + ", tod=" + tod + ", rbc=" + rbc + ", wbc=" + wbc + ", platelet=" + platelet
				+ "]";
	}
	 
	
	

}

