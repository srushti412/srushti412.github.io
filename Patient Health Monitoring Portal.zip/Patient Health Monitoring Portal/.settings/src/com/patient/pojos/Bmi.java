package com.patient.pojos;

public class Bmi {
	private String userid;
	private int height;
	private int weight;
	private float bmi_value;
	public float getBmi_value() {
		return bmi_value;
	}
	public void setBmi_value(float bmi_value) {
		this.bmi_value = bmi_value;
	}
	public int getHeight() {
		return height;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public void setHeight(int height) {
		this.height = height;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	@Override
	public String toString() {
		return "Bmi [userid=" + userid + ", height=" + height + ", weight=" + weight + ", bmi_value=" + bmi_value + "]";
	}
	

}
